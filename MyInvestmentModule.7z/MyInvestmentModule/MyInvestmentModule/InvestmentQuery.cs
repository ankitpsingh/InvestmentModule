﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInvestmentModule
{
    //1st module: investor is sending the investment query with it's priority.
    class InvestmentQuery : IComparable<InvestmentQuery>
    {
        public string StockID { get; set; }
        public int Priority { get; set; }
        public DateTime QueryTime { get; set; }        
        public Guid Investor { get; set; }

        public int CompareTo(InvestmentQuery other)
        {
            int _compare = Priority.CompareTo(other.Priority);
            if (_compare != 0)
                return _compare;
            return QueryTime.CompareTo(other.QueryTime);
        }
    }
}
