﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInvestmentModule
{
    //#copied from PriorityQueueUsingMinBinaryHeap solution
    class MinBinaryHeap<T> where T : IComparable<T>
    {
        int capacity;
        T[] dynamicArray;
        public MinBinaryHeap(int _capacity)
        {
            capacity = _capacity;
            dynamicArray = new T[capacity];
        }
        public MinBinaryHeap() : this(8) { }

        int currentIndex = 0;
        public void Insert(T item)
        {
            currentIndex++;
            if (currentIndex >= capacity)
            {
                capacity *= 2;
                T[] tempArray = dynamicArray;
                dynamicArray = new T[capacity];
                tempArray.CopyTo(dynamicArray, 0);
            }
            dynamicArray[currentIndex] = item;
            BalancingFromBottom();
        }
        private void BalancingFromBottom()
        {
            bool IsBalancingRequired = true;
            int parentIndex;
            int tempIndex = currentIndex;
            while (IsBalancingRequired && tempIndex > 1)
            {
                parentIndex = tempIndex / 2;
                if (dynamicArray[parentIndex].CompareTo(dynamicArray[tempIndex]) > 0)
                {
                    T temp = dynamicArray[parentIndex];
                    dynamicArray[parentIndex] = dynamicArray[tempIndex];
                    dynamicArray[tempIndex] = temp;
                }
                else
                {
                    IsBalancingRequired = false;
                }
                tempIndex = parentIndex;
            }
        }
        public T Remove()
        {
            if (currentIndex == 0)
                throw new InvalidOperationException("No element!!!");
            T temp = dynamicArray[1];
            dynamicArray[1] = dynamicArray[currentIndex];
            currentIndex--;
            BalancingFromTop();
            return temp;
        }
        private void BalancingFromTop()
        {
            bool IsBalancingRequired = true;
            int childIndex;
            int tempIndex = 1;
            while (IsBalancingRequired && ((tempIndex * 2) < currentIndex))
            {
                childIndex = dynamicArray[2 * tempIndex].CompareTo(dynamicArray[(2 * tempIndex) + 1]) < 0 ? 2 * tempIndex : (2 * tempIndex) + 1;
                if (dynamicArray[childIndex].CompareTo(dynamicArray[tempIndex]) < 0)
                {
                    T temp = dynamicArray[childIndex];
                    dynamicArray[childIndex] = dynamicArray[tempIndex];
                    dynamicArray[tempIndex] = temp;
                }
                else
                {
                    IsBalancingRequired = false;
                }
                tempIndex = childIndex;
            }
        }

        public int Count
        {
            get { return currentIndex; }
        }
        public IEnumerable<T> ToArray()
        {
            return dynamicArray.ToArray();
        }
    }
}
