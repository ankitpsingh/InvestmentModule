﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInvestmentModule
{
    class Program
    {
        static Random rand = new Random(29);
        static void Main(string[] args)
        {
            StockTrader stockTrader = new StockTrader();
            InvestmentAnalyzer analyzer = new InvestmentAnalyzer(stockTrader);
            Stopwatch _stopWatch = new Stopwatch();

            #region SimulateCreationOfQueries
            Console.WriteLine("Simulate creation of queries");
            _stopWatch.Start();
            for (int i = 0; i < 50000; i++)
            {
                analyzer.AddQuery(CreateQuery());
            }
            Console.WriteLine("Time Taken in query creation is: {0}", Math.Round(_stopWatch.Elapsed.TotalSeconds, 2));
            #endregion
            #region AnalyzeQueries
            Console.WriteLine("AnalyzingQueries");
            _stopWatch.Restart();
            analyzer.AnalyzeQueries();
            Console.WriteLine("Completed in {0}", Math.Round(_stopWatch.Elapsed.TotalSeconds, 2));
            #endregion
            #region HandleTradings
            Console.WriteLine("Handling of Trading is");
            _stopWatch.Restart();
            stockTrader.HandleTradings();
            Console.WriteLine("completed in {0}", Math.Round(_stopWatch.Elapsed.TotalSeconds, 2));
            #endregion
            Console.ReadLine();
        }
        static InvestmentQuery CreateQuery()
        {
            return new InvestmentQuery()
            {
                StockID = "Stock" + rand.Next(10000),
                Priority = rand.Next(5),
                Investor = new Guid(),
                QueryTime = DateTime.Now
            };
        }
    }
    #region Information
    //With Dynamic Arrays(List) it took 95 secs in analyzing. Creation: 0.03 Handling: 0.04
    //After applying Linked List it took 100 secs in analyzing. Creation: 0.03 Handling: 0.0 sec in handling
    //After applying C5.IntervalHeap it took 7.62 secs in analyzing. Creation: 0.03 Handling: 0.0    
    //After applying HashTable(Dictionary) it took 0.15 secs in analyzing. Creation: 0.03 Handling: 0.0 
    //using custom made priority queue instead of C5.Interval heap took around 0.11 sec in analyzing. Creation: .03 Handling: 0.0   
    #endregion
}
