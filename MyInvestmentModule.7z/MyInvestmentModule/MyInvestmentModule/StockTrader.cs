﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MyInvestmentModule
{
    interface IStockTrader
    {
        void EnqueueStockForTrading(InvestmentQuery query);
        void HandleTradings();
    }
    //using Linked list instead of list becoz of better performance while adding or removing.
    //And since we are storing InvestmentQuery, overhead of maintaing the pointer is also balanced.
    class StockTrader : IStockTrader
    {
        //List<InvestmentQuery> queries = new List<InvestmentQuery>();
        LinkedList<InvestmentQuery> queries = new LinkedList<InvestmentQuery>();
        public void EnqueueStockForTrading(InvestmentQuery query)
        {
            //queries.Add(query);
            queries.AddLast(query);
        }
        public void HandleTradings()
        {
            Console.WriteLine(queries.Count);
            while(queries.Count > 0)
            {
                //var query = queries.First();
                var query = queries.First;
                //Here simulation of actual trading will be present.
                //queries.Remove(query);
                queries.RemoveFirst();
                //Thread.Sleep(100);
            }
        }
    }
}
