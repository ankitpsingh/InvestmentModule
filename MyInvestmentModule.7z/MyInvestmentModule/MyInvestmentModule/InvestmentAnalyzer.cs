﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MyInvestmentModule
{
    //using Dictionary(hash table) for storing cache.
    //class RatingCache
    //{
    //    public string StockID { get; set; }
    //    public int Rating { get; set; }
    //    public RatingCache(string _stockID, int _rating)
    //    {
    //        StockID = _stockID;
    //        Rating = _rating;
    //    }
    //}

    //Used C5.IntervalHeap instead of List becoz, finding minimum or maximum element from this is having complexity
    //of O(1) whereas in List it is O(N).
    class InvestmentAnalyzer
    {
        IStockTrader stockTrader;
        //List<InvestmentQuery> queries;
        //C5.IntervalHeap<InvestmentQuery> queries;
        MinBinaryHeap<InvestmentQuery> queries;
        //List<RatingCache> ratingCache;
        Dictionary<string, int> stockRatingDictionary;
        Random rand = new Random(29);
        public InvestmentAnalyzer(IStockTrader _stockTrader)
        {
            stockTrader = _stockTrader;
            //queries = new List<InvestmentQuery>();
            queries = new MinBinaryHeap<InvestmentQuery>();
            //ratingCache = new List<RatingCache>();
            stockRatingDictionary = new Dictionary<string, int>();
        }

        public void AddQuery(InvestmentQuery query)
        {
            //queries.Add(query);
            queries.Insert(query);
        }
        public void AnalyzeQueries()
        {
            while(queries.Count > 0)
            {
                int rating = 0;
                //InvestmentQuery query = queries.DeleteMin();
                InvestmentQuery query = queries.Remove();
                //RatingCache cache = ratingCache.Find(x => x.StockID == query.StockID);
                //if (cache != null)
                //    rating = cache.Rating;
                if (stockRatingDictionary.ContainsKey(query.StockID))
                    rating = stockRatingDictionary[query.StockID];
                else
                {
                    rating = CalculateRating(query.StockID);
                    //ratingCache.Add(new RatingCache(query.StockID, rating));
                    stockRatingDictionary.Add(query.StockID, rating);
                }
                if (rating > 80)
                    stockTrader.EnqueueStockForTrading(query);
            }
        }

        private int CalculateRating(string _stockID)
        {
            //Simulate some computation time that might involve fetching data from various external data sources.
            //Thread.Sleep(100);
            return rand.Next(100);
        }
        //private InvestmentQuery GetPriorityQuery()
        //{
        //    InvestmentQuery priorityQuery = null;
        //    foreach (var query in queries)
        //    {
        //        if (priorityQuery == null || query.CompareTo(priorityQuery) < 0)
        //            priorityQuery = query;
        //    }
        //    queries.Remove(priorityQuery);
        //    return priorityQuery;
        //}
    }
}
